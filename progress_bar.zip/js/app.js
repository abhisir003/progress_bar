var app = angular.module('kumarApp', []);
app.controller('calculate', function($scope) {
    $scope.ptitle = 'Progress Bar ';
    $scope.progressmin = 62;
    $scope.progressmin1 = 25;
    $scope.progressmin2 = 45;
    $scope.min = 0;
    $scope.max = 230;
    $scope.temp = $scope.max / 100;
    $scope.error = false;
    $scope.increment = function() {
        var currentvalue = $scope.progressmin + 10;
        $scope.progressmin = parseInt(currentvalue);
        $scope.progressmin1 = parseInt(currentvalue / $scope.temp);
        if ($scope.progressmin >= $scope.max) {
            $scope.error = true;
        }

    };
    $scope.increment1 = function() {
        var currentvalue = $scope.progressmin + 38;
        $scope.progressmin = parseInt(currentvalue);
        $scope.progressmin1 = parseInt(currentvalue / $scope.temp);
        if ($scope.progressmin >= $scope.max) {
            $scope.error = true;
        }

    };

    $scope.decrement = function() {
        var currentvalue = $scope.progressmin - 13;
        $scope.progressmin = parseInt(currentvalue);
        $scope.progressmin1 = parseInt(currentvalue / $scope.temp);

        if ($scope.progressmin <= $scope.min) {
            $scope.progressmin = 0;

        }
        if ($scope.progressmin <= $scope.max) {
            $scope.error = false;
        }
    }
    $scope.decrement1 = function() {
        var currentvalue = $scope.progressmin - 18;
        $scope.progressmin = parseInt(currentvalue);
        $scope.progressmin1 = parseInt(currentvalue / $scope.temp);

        if ($scope.progressmin <= $scope.min) {
            $scope.progressmin = 0;

        }
        if ($scope.progressmin <= $scope.max) {
            $scope.error = false;
        }
    }
    $scope.first = function() {
        angular.element('.ct-btn .btn').addClass('bg-color-blue').removeClass('bg-color-green').removeClass('bg-color-orange');



    }
    $scope.second = function() {
        angular.element('.ct-btn .btn').addClass('bg-color-green').removeClass('bg-color-blue').removeClass('bg-color-orange');



    }
    $scope.third = function() {
        angular.element('.ct-btn .btn').addClass('bg-color-orange').removeClass('bg-color-blue').removeClass('bg-color-green');
        //var bar = document.getElementsByClassName('barC');
        //angular.element(bar).scope(false);

    }
    $scope.unbind = function() {
        return function(scope, tElement, attributes) {
            scope.$on('$destroy', function() {

            });
        };
    }
    $scope.stopBinding = function() {
        angular.element(document.getElementsByClassName('barA')).unbind();
    };

});
app.directive('progressBar', function() {
    return {

        rectrict: 'EA',
        template: '<div class="progress barA"><div class ="progress-bar bg-info" role ="progressbar" style = "width:{{progressmin1}}%" ng-class ="{error: error}"><span>{{progressmin}}</span></div></div>',
        scope: {
            style: '=',

        },

        compile: function($scope, tElement, tAttr) {
            $scope.third = function() {
                var barA = document.getElementsByClassName('progress-bar');
                angular.element(barA).scope().$destroy();
            }
        },

    }
})