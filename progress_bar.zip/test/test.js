describe('Mathematics calulation test', function() {
    var x = 10;
    var y = 30;
    result = (x + y);
    it('Addition of two numbers', function() {
        expect(result).toBe(40)
    });
});

describe("A suite is just a function", function() {
    var a;

    it("and so is a spec", function() {
        a = true;

        expect(a).toBe(true);
    });
});

//controller Test Cases
var $controller;
describe('controller testing', function() {
    beforeEach(module("kumarApp"));
    beforeEach(inject(function(_$controller_) {
        $controller = _$controller_;
    }));
    it('Progress Bar Test Cases', function() {
        var $controller = $controller('calculate', { $scope: {} });
        controller.result(30);
        expect(controller.result).toBe(30);
    });
});